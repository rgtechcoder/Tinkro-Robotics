import { DashboardLayout } from "@/components/DashboardLayout";
import { useUserAuth } from "@/context/UserAuthContext";
import { useEffect } from "react";
import { useNavigate } from "@tanstack/react-router";
import {
  DashboardAddresses,
  DashboardCoupons,
  DashboardOrders,
  DashboardOverview,
  DashboardProfile,
  DashboardTracking,
} from "@/components/dashboard";
import { AnimatePresence, motion } from "motion/react";
import type { ComponentType } from "react";
import { useState } from "react";
import { upsertLinkTag, upsertMetaTag } from "../lib/seo";

type Section =
  | "overview"
  | "orders"
  | "tracking"
  | "addresses"
  | "coupons"
  | "profile";

const SECTION_COMPONENTS: Record<Section, ComponentType> = {
  overview: DashboardOverview,
  orders: DashboardOrders,
  tracking: DashboardTracking,
  addresses: DashboardAddresses,
  coupons: DashboardCoupons,
  profile: DashboardProfile,
};

export function DashboardPage() {
  const [activeSection, setActiveSection] = useState<Section>("overview");
  const { user, isLoading } = useUserAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const title = "Dashboard | Tinkro";
    const description = "Manage your Tinkro orders, addresses, and profile.";
    const canonicalUrl = "https://tinkro.in/dashboard";

    document.title = title;
    upsertLinkTag("canonical", canonicalUrl);
    upsertMetaTag("name", "description", description);
    upsertMetaTag("name", "robots", "noindex,follow");
  }, []);

  useEffect(() => {
    if (!isLoading && !user) {
      navigate({ to: "/login" });
    }
  }, [user, isLoading, navigate]);

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center text-lg">Loading...</div>;
  }
  if (!user) {
    // Optionally render nothing while redirecting
    return null;
  }

  const SectionComponent = SECTION_COMPONENTS[activeSection];

  return (
    <DashboardLayout
      activeSection={activeSection}
      onSectionChange={(s) => setActiveSection(s as Section)}
    >
      <AnimatePresence mode="wait">
        <motion.div
          key={activeSection}
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.22, ease: [0.4, 0, 0.2, 1] }}
        >
          <SectionComponent />
        </motion.div>
      </AnimatePresence>
    </DashboardLayout>
  );
}
